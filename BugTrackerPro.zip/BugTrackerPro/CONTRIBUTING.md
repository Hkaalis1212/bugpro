# Contributing to AI-Powered Bug Reporting System

We welcome contributions to make this bug reporting system even better! This guide will help you get started.

## 🚀 Getting Started

### Prerequisites
- Python 3.11+
- PostgreSQL 16+
- Git
- Basic understanding of Flask and SQLAlchemy

### Development Setup

1. **Fork and clone the repository**
   ```bash
   git clone https://github.com/yourusername/bug-reporting-system.git
   cd bug-reporting-system
   ```

2. **Set up development environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Initialize database**
   ```bash
   python -c "from app import app, db; app.app_context().push(); db.create_all()"
   ```

5. **Run tests to ensure everything works**
   ```bash
   python comprehensive_tests.py
   ```

## 📋 How to Contribute

### Reporting Bugs
1. Check if the bug already exists in [GitHub Issues](../../issues)
2. Create a new issue with detailed information:
   - Clear description of the problem
   - Steps to reproduce
   - Expected vs actual behavior
   - Environment details (OS, Python version, etc.)
   - Screenshots if applicable

### Suggesting Features
1. Check existing [Feature Requests](../../issues?q=is%3Aissue+is%3Aopen+label%3Aenhancement)
2. Create a new issue with the "enhancement" label
3. Describe the feature and its benefits
4. Include use cases and examples

### Code Contributions

#### Branch Naming Convention
- `feature/description-of-feature` - New features
- `bugfix/description-of-fix` - Bug fixes
- `hotfix/critical-issue` - Critical fixes
- `docs/documentation-update` - Documentation changes

#### Pull Request Process

1. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes**
   - Follow the existing code style
   - Add tests for new functionality
   - Update documentation as needed

3. **Test your changes**
   ```bash
   # Run the full test suite
   python comprehensive_tests.py
   
   # Run specific tests
   python test_runner.py
   python integration_test.py
   
   # Check for security issues
   python -m pytest tests/ -v
   ```

4. **Commit your changes**
   ```bash
   git add .
   git commit -m "feat: add new feature description"
   ```
   
   Use conventional commit messages:
   - `feat:` - New features
   - `fix:` - Bug fixes
   - `docs:` - Documentation changes
   - `test:` - Test additions/changes
   - `refactor:` - Code refactoring
   - `style:` - Code style changes

5. **Push and create pull request**
   ```bash
   git push origin feature/your-feature-name
   ```
   
   Then create a pull request through GitHub with:
   - Clear title and description
   - Reference to related issues
   - Screenshots if UI changes
   - Testing information

## 🎯 Development Guidelines

### Code Style
- Follow PEP 8 for Python code
- Use descriptive variable and function names
- Add docstrings to functions and classes
- Keep functions focused and small
- Use type hints where appropriate

### Database Changes
- Create migrations for schema changes
- Test migrations both up and down
- Document breaking changes
- Consider backward compatibility

### Frontend Guidelines
- Use TailwindCSS for styling
- Ensure responsive design
- Test across different browsers
- Maintain accessibility standards

### Testing Requirements
- Write unit tests for new functions
- Add integration tests for new endpoints
- Test error cases and edge conditions
- Maintain test coverage above 80%

### Security Considerations
- Validate all user inputs
- Use parameterized queries
- Sanitize file uploads
- Follow OWASP guidelines
- Test for common vulnerabilities

## 🔍 Code Review Process

All contributions go through code review:

1. **Automated checks** - Tests and linting must pass
2. **Manual review** - Code quality and design review
3. **Testing verification** - Functionality testing
4. **Documentation review** - Ensure docs are updated

### Review Criteria
- Code follows project standards
- Tests are comprehensive
- Documentation is complete
- No security vulnerabilities
- Performance considerations
- Backward compatibility

## 📝 Documentation

### Code Documentation
- Add docstrings to all public functions
- Document complex algorithms
- Include usage examples
- Update API documentation

### User Documentation
- Update README.md for new features
- Add installation steps for new dependencies
- Include configuration examples
- Update troubleshooting guides

## 🐛 Debugging and Troubleshooting

### Common Issues
- **Database connection errors**: Check DATABASE_URL and PostgreSQL status
- **Import errors**: Ensure all dependencies are installed
- **API key errors**: Verify environment variables are set
- **Permission errors**: Check file permissions and user roles

### Debugging Tools
- Use `app.logger` for application logging
- Enable Flask debug mode for development
- Use PostgreSQL logs for database issues
- Browser developer tools for frontend issues

## 🚀 Release Process

1. **Version updates** - Follow semantic versioning
2. **Changelog updates** - Document all changes
3. **Testing** - Full test suite passes
4. **Documentation** - All docs are current
5. **Deployment** - Test in staging environment

## 📞 Getting Help

- **GitHub Issues** - For bugs and feature requests
- **GitHub Discussions** - For questions and community support
- **Documentation** - Check README.md and code comments
- **Email** - Contact maintainers for sensitive issues

## 🎉 Recognition

Contributors will be recognized in:
- CONTRIBUTORS.md file
- Release notes
- GitHub contributors page

Thank you for contributing to the AI-Powered Bug Reporting System!