# Bug Reporting System

A comprehensive AI-powered bug reporting system with user authentication, file uploads, and admin dashboard.

## Features

- 🤖 **AI-Powered Analysis**: Automatically extracts reproduction steps from bug descriptions using OpenAI
- 🔐 **User Authentication**: Login/register system with role-based access control
- 📎 **File Attachments**: Drag-and-drop file upload with support for images, logs, and documents
- 👨‍💼 **Admin Dashboard**: Comprehensive management interface for viewing and managing bug reports
- 🗄️ **Database Storage**: PostgreSQL database for persistent data storage
- 🧪 **Test Automation**: Playwright-based testing with automated replay capabilities

## Quick Start

### Prerequisites
- Python 3.11+
- PostgreSQL database
- OpenAI API key

### Installation

1. Install dependencies:
```bash
pip install flask flask-sqlalchemy flask-login openai playwright
```

2. Set environment variables:
```bash
export DATABASE_URL="postgresql://username:password@host:port/database"
export OPENAI_API_KEY="your-openai-api-key"
export SESSION_SECRET="your-secret-key"
```

3. Create admin user:
```bash
curl http://localhost:5000/create-admin
```

4. Run the application:
```bash
python main.py
```

## Usage

### Bug Reporting
1. Visit the homepage
2. Fill in the bug title and description
3. Optionally attach files by dragging and dropping
4. Submit the report
5. View AI-generated reproduction steps

### Authentication
- **Register**: Create a new account at `/register`
- **Login**: Sign in at `/login`
- **Demo Admin**: Use `admin@example.com` / `admin123`

### Admin Dashboard
- Access at `/admin` (admin users only)
- View all bug reports with search and pagination
- Download attachments
- Delete reports individually or in bulk
- View system statistics

## Test Automation

The system includes comprehensive test automation using Playwright:

### Run Tests
```bash
# Run all test suites
python run_tests.py all

# Run specific login test
python run_tests.py login

# Run custom test actions
python test_automation.py '[{"action": "click", "selector": "#login"}]'
```

### Test Scenarios
- **Login Flow**: Tests user authentication process
- **Bug Submission**: Tests complete bug reporting workflow
- **Admin Dashboard**: Tests admin access and functionality

### Test Features
- 📹 **Video Recording**: Automatically records test sessions
- 📸 **Screenshots**: Captures final states and errors
- 📋 **Detailed Reports**: JSON reports with execution details
- 🔄 **Error Recovery**: Graceful handling of test failures

## API Endpoints

### Public Endpoints
- `GET /` - Main bug reporting interface
- `POST /submit` - Submit a new bug report
- `GET /login` - Login page
- `POST /login` - Authenticate user
- `GET /register` - Registration page
- `POST /register` - Create new user account

### Admin Endpoints (Authentication Required)
- `GET /admin` - Admin dashboard
- `GET /reports` - Get paginated bug reports
- `DELETE /reports/<id>` - Delete specific bug report
- `GET /reports/<id>/download/<attachment_id>` - Download attachment

## Database Schema

### Users Table
- `id` - Primary key
- `email` - Unique email address
- `password_hash` - Hashed password
- `first_name` - User's first name
- `last_name` - User's last name
- `is_admin` - Admin flag
- `created_at` - Registration timestamp

### Bug Reports Table
- `id` - Primary key
- `title` - Bug report title
- `description` - Detailed description
- `parsed_steps` - AI-generated reproduction steps
- `user_id` - Foreign key to users table
- `created_at` - Submission timestamp

### Attachments Table
- `id` - Primary key
- `filename` - Original filename
- `file_size` - File size in bytes
- `content` - Base64 encoded file content
- `bug_report_id` - Foreign key to bug reports table

## Security Features

- Password hashing using Werkzeug
- Session-based authentication
- Role-based access control
- File type validation
- File size limits (10MB per file)
- SQL injection protection via SQLAlchemy ORM

## Configuration

### File Upload Settings
- **Max File Size**: 10MB per file
- **Allowed Types**: PNG, JPG, JPEG, GIF, PDF, TXT, LOG, JSON, XML
- **Storage**: Base64 encoded in database

### AI Settings
- **Model**: GPT-4o (latest OpenAI model)
- **Max Tokens**: 500 for reproduction steps
- **Temperature**: 0.3 for consistent outputs

## Deployment

The application is configured for deployment on Replit with:
- Gunicorn WSGI server
- Auto-restart on file changes
- Environment variable management
- PostgreSQL database integration

## Contributing

1. Create feature branches for new functionality
2. Add tests for new features
3. Ensure all tests pass before merging
4. Update documentation as needed

## License

This project is open source and available under the MIT License.